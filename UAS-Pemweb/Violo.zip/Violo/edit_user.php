<?php 
	include 'koneksi.php';
	include 'link.php';
	
	$id_user = $_GET['id_user'];

	$query = mysqli_query($conn,"SELECT * FROM user WHERE id_user = '$id_user'");

	$data = mysqli_fetch_array($query);

	if (isset($_POST['ubah'])) {
		
		$email = $_POST['email'];
		$username = $_POST['username'];
		$password = md5($_POST['password']);
        $no_telp = $_POST['no_telp'];
		$role = $_POST['role'];

		$query = mysqli_query($conn,"UPDATE user SET email = '$email', username = '$username', password = '$password', no_telp = '$no_telp', role = '$role' WHERE id_user = '$id_user'");

		if ($query) {
			echo "<script>alert('Data Users berhasil diubah'); window.location='pengguna.php';</script>";
		}else{
			echo "<script>alert('Data Users gagal diubah'); window.location='edit_user.php';</script>";
		}
	}

 ?><br>

 	<div class="container">
 		<div class="panel panel-default">
		<div class="panel-heading">
        	<h2>Ubah Users</h2>
			<a href="pengguna.php" class="btn mb-5" style="color:#EF9273;">Kembali</a>
		</div>

 		<div class="panel-body">
 			<form action="" method="POST">
 
	 <div class="form-group">
		<label class="control-label col-sm-2" name="email">E-mail</label>
		<div class="col-md-10" >
			<input type="text" name="email" class="form-control" value="<?php echo $data['email'] ?>">
		</div>
	</div>

	<div class="form-group mt-5">
		<label class="control-label col-sm-2" name="username">Username</label>
		<div class="col-md-10" >
			<input type="text" name="username" class="form-control" value="<?php echo $data['username'] ?>">
		</div>
	</div>

 	<div class="form-group mt-5">
		<label class="control-label col-sm-2" name="password">Password</label>
		<div class="col-md-10" >
			<input type="password" name="password" class="form-control" value="<?php echo $data['password'] ?>">
		</div>
	</div>

    <div class="form-group mt-5">
		<label class="control-label col-sm-2" name="no_telp">No. Telpon</label>
		<div class="col-md-10" >
			<input type="text" name="no_telp" class="form-control" value="<?php echo $data['no_telp'] ?>">
		</div>
	</div>

	<div class="form-group mt-5">
		<label class="control-label col-sm-2" name="role">Jabatan</label>
		<div class="col-md-10" >
			<select name="role" class="form-control"  value="<?php echo $data['role'] ?>" >
				<option selected disabled>Pilih Jabatan</option>
				<option value="Admin">Admin</option>
				<option value="Seller">Seller</option>
                <option value="Buyer">Buyer</option>
			</select>	
		</div>
	</div>

	<div class="form-group">        
     	<div class="col-sm-offset-2 col-sm-10 text-center">
        	<!-- <button type="submit" class="btn btn-info btn-sm" name="ubah">Ubah</button> -->
            <button type="submit" style="width: 150px; background: #EF9273; border-style: 1 solid;" class="btn text-light mt-3" name="ubah">Submit</button>
    	</div>
    </div>

 </form>
</div>
</div>

</div>
 <?php 
 include 'footer.php';

  ?>