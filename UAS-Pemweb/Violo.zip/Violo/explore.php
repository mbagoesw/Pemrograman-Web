<?php
session_start();
include 'koneksi.php';
include 'link.php';

if (empty($_SESSION['masuk'])) {
    header("location:index.php");
}
?>

<title>Explore</title>

<!-- Ini Nav -->
<nav class="navbar navbar-expand-sm navbar-dark">

    <div class="container">
        <a class="navbar-brand" href="#">
            <img src="img/Violocut.png" class="vio-bg" alt="Violo" style="width : 140px; height: auto; margin: 20px;">
        </a>
        <ul class="nav justify-content-end">

            <?php if ($_SESSION['role'] == 'Admin') { ?>
                <li class="nav-item">
                    <a class="nav-link text-dark" href="pengguna.php">Users</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link text-dark" href="seler.php">Seller</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link text-dark" href="buyer.php">Buyer</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link text-dark" href="kategori.php">Kategori</a>
                </li>

               


            <?php } ?>

            <?php if ($_SESSION['role'] == 'Seller') { ?>
            <li class="nav-item">
                <a class="nav-link text-dark" href="explore.php">Explore</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-dark" href="contact.php">Contact</a>
            </li>
            <?php } ?>

            <?php if ($_SESSION['role'] == 'Buyer') { ?>
            <li class="nav-item">
                <a class="nav-link text-dark" href="explore.php">Explore</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-dark" href="contact.php">Contact</a>
            </li>
            <?php } ?>
            

            <div class="dropdown">
                <button type="button" class="btn dropdown-toggle" data-bs-toggle="dropdown">
                    <a class="navbar-brand" href="#">
                        <img src="img/user.png" alt="Avatar" class="rounded-pill" style="width: 30px; height: auto;">
                    </a>
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="profile_seller.php">Profile (<?php echo ($_SESSION['username']); ?>)</a></li>
                   <?php if ($_SESSION['role'] == 'Seller') { ?>
                    <li><a class="dropdown-item" href="input_seller.php">Create Your Shop</a></li>
                    <?php } ?>
                    <li><a class="dropdown-item" href="signout.php">Sign Out</a></li>
                </ul>
            </div>
        </ul>
    </div>
</nav>

<!-- Ini Search -->
<div class="container">
    <form action="" method="get" class="d-flex">
        <input class="form-control" type="text" placeholder="Find My Needs.." style="border-radius: 10px; border-color:#EF9273; border-style:solid;" name="cari">
        <button class="btn" type="submit" value="Cari" style="color:#EF9273;">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
            </svg>
        </button>
        <!-- <input type="submit" value="Cari"> -->
    </form>

    <?php
    if (isset($_GET['cari'])) {
        $cari = $_GET['cari'];
        $sql = mysqli_query($conn, "SELECT * FROM seller where nama_seller like '%" . $cari . "%'");
        $data = mysqli_fetch_array($sql);
    } else {
        $sql = mysqli_query($conn, "SELECT * FROM seller");
        $data = mysqli_fetch_array($sql);
    }
    ?>
    <!-- <form class="d-flex">
        <input class="form-control" type="text" placeholder="Find My Needs.." style="border-radius: 10px; border-color:#EF9273; border-style:solid;">
        <button class="btn" type="button" style="color:#EF9273;">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
            </svg>
        </button>
    </form> -->
</div>

<!-- Ini Kategori -->
<div class="container">
    <ul class="nav justify-content-center">
        <li data-filter="*" class="nav-item filter-active">
            <button type="button" class="btn nav-link text-light me-4 " href="#" style="width: 185px; border-radius: 10px; background:#EF9273;">All</button>
        </li>
        <li data-filter=".filter-Copywriting" class="nav-item">
            <button type="button" class="btn nav-link text-light me-4" href="#" style="width: 185px; border-radius: 10px; background:#EF9273;">Copywriting</button>
        </li>
        <li data-filter=".filter-Web-Design" class="nav-item">
            <button type="button" class="btn nav-link text-light me-4" href="#" style="width: 185px; border-radius: 10px; background:#EF9273;">Web Design</button>
        </li>
        <li data-filter=".filter-Logo-Design" class="nav-item">
            <button type="button" class="btn nav-link text-light me-4" href="#" style="width: 185px; border-radius: 10px; background:#EF9273;">Logo Design</button>
        </li>
        <li data-filter=".filter-Video Editor" class="nav-item">
            <button type="button" class="btn nav-link text-light me-4" href="#" style="width: 185px; border-radius: 10px; background:#EF9273;">Video Editor</button>
        </li>

    </ul>
</div>

<!-- Ini Card Seller -->
<div class="container">
    <div class="row text-center mb-3 mt-5">
        <?php
        $sql = "SELECT * FROM seller ";
        $query = mysqli_query($conn, $sql);
        $cek_tbl = mysqli_num_rows($query) > 0;

        if ($cek_tbl) {
            while ($data = mysqli_fetch_assoc($query)) {

        ?>
                <div class="col-md-3 pb-3">
                    <div class="card">

                        <div class="card-body">
                            <div class="row">
                                <img src="img/<?php echo $data['logo']; ?>" class="card-img-top">

                                <div class="col-lg-12">
                                    <p class="card-text text-light" style="background:#EF9273;">
                                        <a href="#" class="text-light" style="text-decoration:none; font-size:20px;">
                                            <?php echo $data['nama_seller']; ?><br>
                                        </a>

                                        <a href="#" class="text-light" style="text-decoration:none; font-size:15px;">
                                            <?php echo $data['kategori']; ?>
                                        </a>

                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="card-footer">
                            <p class="card-text"><?php echo $data['nama_shop']; ?></p>

                        </div>

                    </div>
                </div>

        <?php
            }
        } else {
            echo "No data found!";
        }
        ?>
    </div>
</div>

<!-- Ini Footer -->
<?php
include 'footer.php';
?>