<br><br><br><br><br><br><br><br><br><br><br><br>
  <div class="navbar navbar-fixed-bottom" style="background:#EF9273;" >
   
    <div class="row">
        <div class="col-md-4">
            <img src="img/violodes.png" style="width:300px;">
        </div>

        <div class="col-md-4 mt-4">
            <p class="text-light text-center mb-3" style="margin-left:150px;">Follow our social media</p>
            <a href="https://twitter.com/violo_twt">
                <img src="img/twt.png" style="width:45px; margin-left:215px; ">
            </a>

            <a href="https://instagram.com/violo_ig">
                <img src="img/ig.png" style="width:45px; margin-left:15px;">
            </a>
        </div>

        <div class="col-md-4 mt-2">
            <img src="img/violocontact.png" style="width:300px; margin-left:200px;">
        </div>

    </div>

       
    </div>
  </div> 

</body>
</html>