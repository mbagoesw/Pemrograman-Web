<?php 
	include 'koneksi.php';
	include 'link.php';

	$id_user = $_GET['id_user'];

	$sql = mysqli_query($conn, "DELETE FROM user WHERE id_user = '$id_user'");

	if ($sql) {
		echo "<script>alert('Data Users berhasil dihapus'); window.location='pengguna.php';</script>";
	}else{
		echo "<script>alert('Data Users gagal dihapus');</script>";
	}

 ?>


  <?php 
 include 'footer.php';

  ?>