<!-- home utama sebelum login! -->
<?php
  include 'koneksi.php';
  include 'link.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Violo</title>

</head>

<style>
  body{
    padding: 0;
    margin: 0;
    display: block;
    background: url(img/bg.png) no-repeat;
}
</style>

<body>
  <div class="container-fluid">
   
    <div class="row">
      <div class="col-sm-4">
        <img src="img/Violocut.png" class="vio-bg" alt="Violo">
      </div>
    </div>

    <div class="row">
      <div class="col-md-6">
        <img src="img/Text-Home.png" class="text-home" alt="Violo">
        <img src="img/Text-Home2.png" class="text-home2" alt="Violo"><br><br>
        <a class="btn button-start" href="#" data-bs-toggle="modal" data-bs-target="#ModalForm">
          START HIRING
        </a>
        <br><br>
        
<!-- Modal Form -->
    <div class="modal fade" id="ModalForm" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          
<!-- Sign In Form -->
            <form action="signin.php" method="POST">
              <div class="modal-header">
                <img src="img/signin1.png" alt="Sign In" class="signin">
              </div>

              <div class="modal-body">
                <div class="mb-3">
                  <img src="img/user.png" alt="Username" style="width: 40px; height: auto; margin-left: 30px; margin-right:10px;">
                  <input type="text" name="username" id="Username" placeholder=" Username.." required style="border-radius: 20px; border-color:#EF9273; border-style:solid; width: 350px; height: 40px;">
              </div>

              <div class="mb-3">
                  <img src="img/pass.png" alt="Password" style="width: 40px; height: auto; margin-left: 30px; margin-right:10px;">
                  <input type="password" name="password" id="Password" placeholder=" Password.."required style="border-radius: 20px; border-color:#EF9273; border-style:solid; width: 350px; height: 40px;">
              </div>

              <p class="fw-bold" style="text-align:right; color: #EF9273; font-family: url("https://fonts.google.com/specimen/Lato");">Don't have an account? 
                <a href="#" style="color: #EF9273;" data-bs-toggle="modal" data-bs-target="#ModalForm2">Sign Up</a>
              
              </p>

              <button type="submit" style="background-color: #EF9273; margin-left:40%; width:105px;" class="btn text-light" name="masuk">Sign In</button>
              </div>
              
              <a href="#" type="button" data-bs-dismiss="modal" aria-label="Close" style="color: #EF9273; margin-left: 10px; margin-bottom:10px; ">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-left-circle-fill" viewBox="0 0 16 16">
                  <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0zm3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5z"/>
                </svg>   
              </a>       

          </form>
        </div>
      </div>
    </div>
<!-- akhir modal Sign In --> 

<!-- Modal Form -->
<div class="modal fade" id="ModalForm2" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          
<!-- SignUp Form -->
            <form action="signup.php" method="POST">
              <div class="modal-header">
                <img src="img/signup.png" alt="Sign Up" class="signup">
              </div>

              <div class="modal-body">
              <div class="mb-3">
                  <img src="img/email.png" alt="email" style="width: 40px; height: auto; margin-left: 30px; margin-right:10px;">
                  <input type="email" name="email" id="email" 
                        placeholder=" E-mail.."required style="border-radius: 20px; border-color:#EF9273; border-style:solid; width: 350px; height: 40px;">
              </div>
              
              <div class="mb-3">
                  <img src="img/user.png" alt="Username" style="width: 40px; height: auto; margin-left: 30px; margin-right:10px;">
                  <input type="text" name="username" id="Username" 
                        placeholder=" Username.." required style="border-radius: 20px; border-color:#EF9273; border-style:solid; width: 350px; height: 40px;">
              </div>

              <div class="mb-3">
                  <img src="img/pass.png" alt="Password" style="width: 40px; height: auto; margin-left: 30px; margin-right:10px;">
                  <input type="password" name="password" id="password" 
                        placeholder=" Password.."required style="border-radius: 20px; border-color:#EF9273; border-style:solid; width: 350px; height: 40px;">
              </div>
                            
              <div class="mb-3">
                  <img src="img/tlp.png" alt="no_tlp" style="width: 40px; height: auto; margin-left: 30px; margin-right:10px;">
                  <input type="no_tlp" name="no_tlp" id="no_tlp" placeholder=" Phone Number.."required style="border-radius: 20px; border-color:#EF9273; border-style:solid; width: 350px; height: 40px;">              
              </div>

              <div class="mb-3">
                  <img src="img/category.png" alt="role" style="width: 40px; height: auto; margin-left: 30px; margin-right:10px;">
                	<select type="role" name="role" id="role" required style="border-radius: 20px; border-color:#EF9273; border-style:solid; width: 350px; height: 40px;">
                    <option selected disabled>Select Category..</option>
                    <!-- <option value="Admin">Admin</option> -->
                    <option value="Seller">Seller</option>
                    <option value="Buyer">Buyer</option>
                  </select>	
              </div>
                
                <!-- <input type="file" name="ava" class="form-control" required style="border-radius: 20px; margin-left:85px; border-color:#EF9273; border-style:solid; width: 350px; height: 40px;"> -->
                    
              <p class="fw-bold" style="text-align:right; color: #EF9273; font-family: url("https://fonts.google.com/specimen/Lato");">Already have an account?  
                <a href="#" style="color: #EF9273;" type="button" data-bs-dismiss="modal" aria-label="Close" >Sign In</a>
              </p>

              <button type="submit" style="background-color: #EF9273; margin-left:40%; width:105px;" class="btn text-light" name="daftar">Sign Up</button>
              </div>
              
              <a href="#" type="button" data-bs-dismiss="modal" aria-label="Close" style="color: #EF9273; margin-left: 10px; margin-bottom:10px; ">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-left-circle-fill" viewBox="0 0 16 16">
                  <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0zm3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5z"/>
                </svg>   
              </a>       
              <!-- <div class="modal-footer pt-4">
                       
              </div> -->

          </form>
        </div>
      </div>
    </div>
<!-- akhir modal SignUp -->

        <a href="https://twitter.com/violo_twt" class="sosmed">
          <i class="bi bi-twitter"></i>
        </a>

        <a href="https://instagram.com/violo_ig" class="sosmed1">
          <i class="bi bi-instagram"></i>
        </a>
      </div>

      <div class="col-md-6">
        <img src="img/Hero2.png" class="visual-home" alt="Hero-bg">
      </div>
    </div>
    