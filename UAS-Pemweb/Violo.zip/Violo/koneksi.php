<?php 
	$host = 'localhost';
	$user = 'root';
	$password = '';
	$database = 'violo';

	$conn = mysqli_connect($host, $user, $password, $database);
 ?>