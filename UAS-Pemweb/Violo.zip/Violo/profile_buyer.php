<?php
session_start();
include 'koneksi.php';
include 'link.php';
  
if (empty($_SESSION['masuk'])) 
{
  header("location:index.php");
}
?>

<title>Profile - Buyer</title>

<!-- Ini Nav -->
<nav class="navbar navbar-expand-sm navbar-dark">

    <div class="container">
        <a class="navbar-brand" href="#">
            <img src="img/Violocut.png" class="vio-bg" alt="Violo" style="width : 140px; height: auto; margin: 20px;">
        </a>
        <ul class="nav justify-content-end">

            <?php if ($_SESSION['role'] == 'Buyer') { ?>
            <li class="nav-item">
                <a class="nav-link text-dark" href="explore.php">Explore</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-dark" href="contact.php">Contact</a>
            </li>
            <?php } ?>
            

            <div class="dropdown">
                <button type="button" class="btn dropdown-toggle" data-bs-toggle="dropdown">
                    <a class="navbar-brand" href="#">
                        <img src="img/user.png" alt="Avatar" class="rounded-pill" style="width: 30px; height: auto;">
                    </a>
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="profile_buyer.php">Profile (<?php echo ($_SESSION['username']); ?>)</a></li>
                    <li><a class="dropdown-item" href="input_buyer.php">Biodata</a></li>
                    <li><a class="dropdown-item" href="signout.php">Sign Out</a></li>

                </ul>
            </div>

        </ul>
    </div>
</nav>

<!-- Ini Search -->
<div class="container">
    <form action="" method="get" class="d-flex">
        <input class="form-control" type="text" placeholder="Find My Needs.." style="border-radius: 10px; border-color:#EF9273; border-style:solid;" name="cari">
        <button class="btn" type="submit" value="Cari" style="color:#EF9273;">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
            </svg>
        </button>
        <!-- <input type="submit" value="Cari"> -->
    </form>

    <?php
    if (isset($_GET['cari'])) {
        $cari = $_GET['cari'];
        $sql = mysqli_query($conn, "SELECT * FROM seller WHERE id_user like '%" . $cari . "%'");
        $data = mysqli_fetch_array($sql);
    } else {
        $sql = mysqli_query($conn, "SELECT * FROM seller");
        $data = mysqli_fetch_array($sql);
    }
    ?>
    <!-- <form class="d-flex">
        <input class="form-control" type="text" placeholder="Find My Needs.." style="border-radius: 10px; border-color:#EF9273; border-style:solid;">
        <button class="btn" type="button" style="color:#EF9273;">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
            </svg>
        </button>
    </form> -->
</div>


<?php
$sqlSell = mysqli_query($conn, "SELECT *FROM buyer WHERE id_user = '" . $_SESSION['id_user'] . "'");
$dataSell = mysqli_fetch_array($sqlSell);

if (($dataSell) == NULL) {
?>
    <center>
        <h2>Kamu Belum Mengisi Biodatamu!</h2>
    </center>

<?php } else {
?>


<div class="container">
        <div class="row">   
            <div class="col text-center">
                <img src="img/<?= $dataSell['foto']; ?>" style="width: 30%; " alt="">
            </div>
        </div>

        <div class="col">
            <div class="col mt-4">
                <h3><?= $dataSell['nama_buyer']; ?></h3>
               <p><?= $dataSell['bio_buyer']; ?></p>
               <p><?= $dataSell['wa']; ?></p>
            </div>
        </div>
    </div>

    
    
<br><br><br><br>
<!-- Ini Footer -->
<?php
}
    include 'footer.php';
?>
