<?php
session_start();
include 'koneksi.php';
include 'link.php';
  
if (empty($_SESSION['masuk'])) 
{
  header("location:index.php");
}
?>

<title>Profile - Seller</title>


<!-- Ini Nav -->
<nav class="navbar navbar-expand-sm navbar-dark">

    <div class="container">
        <a class="navbar-brand" href="#">
            <img src="img/Violocut.png" class="vio-bg" alt="Violo" style="width : 140px; height: auto; margin: 20px;">
        </a>
        <ul class="nav justify-content-end">

            <?php if ($_SESSION['role'] == 'Admin') { ?>
                <li class="nav-item">
                    <a class="nav-link text-dark" href="pengguna.php">Users</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link text-dark" href="seler.php">Seller</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link text-dark" href="buyer.php">Buyer</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link text-dark" href="kategori.php">Kategori</a>
                </li>

               


            <?php } ?>

            <?php if ($_SESSION['role'] == 'Seller') { ?>
            <li class="nav-item">
                <a class="nav-link text-dark" href="explore.php">Explore</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-dark" href="contact.php">Contact</a>
            </li>
            <?php } ?>

            <?php if ($_SESSION['role'] == 'Buyer') { ?>
            <li class="nav-item">
                <a class="nav-link text-dark" href="explore.php">Explore</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-dark" href="contact.php">Contact</a>
            </li>
            <?php } ?>
            

            <div class="dropdown">
                <button type="button" class="btn dropdown-toggle" data-bs-toggle="dropdown">
                    <a class="navbar-brand" href="#">
                        <img src="img/user.png" alt="Avatar" class="rounded-pill" style="width: 30px; height: auto;">
                    </a>
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="profile_seller.php">Profile (<?php echo ($_SESSION['username']); ?>)</a></li>
                    <li><a class="dropdown-item" href="input_seller.php">Create Your Shop</a></li>
                    <li><a class="dropdown-item" href="signout.php">Sign Out</a></li>
                </ul>
            </div>
        </ul>
    </div>
</nav>

<!-- Ini Search -->
<div class="container">
    <form action="" method="get" class="d-flex">
        <input class="form-control" type="text" placeholder="Find My Needs.." style="border-radius: 10px; border-color:#EF9273; border-style:solid;" name="cari">
        <button class="btn" type="submit" value="Cari" style="color:#EF9273;">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
            </svg>
        </button>
        <!-- <input type="submit" value="Cari"> -->
    </form>

    <?php
    if (isset($_GET['cari'])) {
        $cari = $_GET['cari'];
        $sql = mysqli_query($conn, "SELECT * FROM seller where nama_seller like '%" . $cari . "%'");
        $data = mysqli_fetch_array($sql);
    } else {
        $sql = mysqli_query($conn, "SELECT * FROM seller");
        $data = mysqli_fetch_array($sql);
    }
    ?>
    <!-- <form class="d-flex">
        <input class="form-control" type="text" placeholder="Find My Needs.." style="border-radius: 10px; border-color:#EF9273; border-style:solid;">
        <button class="btn" type="button" style="color:#EF9273;">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
            </svg>
        </button>
    </form> -->
</div>

<?php

$sqlSell = mysqli_query($conn, "SELECT *FROM seller WHERE id_user = '" . $_SESSION['id_user'] . "'");
$dataSell = mysqli_fetch_array($sqlSell);

if (($dataSell) == NULL) {
?>
    <center>
        <h2>Kamu Belum Membuat Shopmu!</h2>
    </center>

<?php } else {
?>


    <div class="container">
        <div class="row justify-content-center">
            <div class="col">
                <h3><?= $dataSell['nama_shop']; ?></h3>
            </div>
        </div>
        <div class="row">   
            <div class="col text-center">
                <img src="img/<?= $dataSell['logo']; ?>" style="width: 30%; " alt="">
            </div>
        </div>
        <div class="col">
            <div class="col mt-4">
               <p><?= $dataSell['bio_seller']; ?></p>
            </div>
        </div>
    </div>

    <div class="container">
    <div class="mt-4 p-5 text-white rounded">
    <div class="row">
        <div class="col-sm-2 text-dark">
            <h4>Nama Seller :</h4>
            <h4>Kategori   :</h4>
            <h5>
                <a href="<?= $dataSell['wa']; ?>"><i class="bi bi-whatsapp text-dark"></i></a>
                <a href="<?= $dataSell['ig']; ?>"><i class="bi bi-instagram text-dark"></i></a>
                <a href="<?= $dataSell['fb']; ?>"><i class="bi bi-Facebook text-dark"></i></a>
                <a href="<?= $dataSell['Li']; ?>"><i class="bi bi-linkedin text-dark"></i></a>
            </h5>
           
            
        </div>
        <div class="col-sm-6 text-dark">
            <p><?= $dataSell['nama_seller'];?></p>
            <p><?= $dataSell['kategori'];?></p>
        </div>
    </div>
    </div>
</div>

    <!-- Ini Footer -->
<?php
}
include 'footer.php';
?>