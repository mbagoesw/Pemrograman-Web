<?php
include 'koneksi.php';

if (isset($_POST['simpan'])) {
    // $id_user = $_POST['id_user'];
    $nama_buyer = $_POST['nama_buyer'];
    $bio_buyer = $_POST['bio_buyer'];
    $wa = $_POST['wa'];
    $foto = $_FILES['foto']['name'];
    $ekstensi = $_FILES['foto']['tmp_name'];
           
    $lokasi = "img/" . $foto;

    move_uploaded_file($ekstensi, $lokasi);

    $sql = mysqli_query($conn, "INSERT INTO `buyer` (nama_buyer, bio_buyer, wa, foto) VALUES ('$nama_buyer', '$bio_buyer', '$wa', '$foto')");
    
    if ($sql) {
        echo "<script>alert('Data anda berhasil ditambahkan'); window.location='profile_buyer.php';</script>";
    } else {
        echo "<script>alert('Data anda berhasil ditambahkan'); window.location='profile_buyer.php';</script>";
    }
}
