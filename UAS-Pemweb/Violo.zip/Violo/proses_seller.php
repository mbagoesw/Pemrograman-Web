<?php
include 'koneksi.php';

if (isset($_POST['simpan'])) {
    $id_user = $_POST['id_user'];
    $nama_shop = $_POST['nama_shop'];
    $nama_seller = $_POST['nama_seller'];
    $kategori = $_POST['kategori'];
    $bio_seller = $_POST['bio_seller'];
    $ig = $_POST['ig'];
    $fb = $_POST['fb'];
    $Li = $_POST['Li'];
    $wa = $_POST['wa'];
    $logo = $_FILES['logo']['name'];
    $ekstensi = $_FILES['logo']['tmp_name'];
		
    $lokasi = "img/" . $logo;

    move_uploaded_file($ekstensi, $lokasi);
   

    $sql = mysqli_query($conn, "INSERT INTO `seller` (id_user, nama_shop, nama_seller, kategori, bio_seller, ig, fb, Li, wa, logo) VALUES('$id_user', '$nama_shop', '$nama_seller', '$kategori', '$bio_seller', '$ig', '$fb', '$Li', '$wa', '$logo')");

    if ($sql) {
        echo "<script>alert('Data anda berhasil ditambahkan'); window.location='input_seller.php';</script>";
    } else {
        echo "<script>alert('Coba lagi! Data anda gagal ditambahkan'); </script>";
        // window.location='input_seller.php';
    }
}
