<?php
session_start();
	if (isset($_SESSION['username'])) {
	header("location:dash.php");
}
	include 'koneksi.php';
	
	if (isset($_POST['masuk'])) {
		$username = $_POST['username'];
		$password = md5($_POST['password']);

	$sql = mysqli_query($conn, "SELECT * FROM user WHERE username= '$username' AND password= '$password'");
	
	if($sql->num_rows > 0) {
		$data = mysqli_fetch_array($sql);

		$_SESSION['masuk'] = true;
		$_SESSION['id_user'] = $data['id_user'];
		$_SESSION['username'] = $data['username'];
		$_SESSION['password'] = $data['password'];
		$_SESSION['role'] = $data['role'];
		
		if ($data['role'] == Admin) {
			header("location:dash.php");
		}
		elseif ($data['role'] == Seller) 
			header("location:input_seller.php");

		elseif ($data['role'] == Buyer) 
			header("location:input_buyer.php");

		}
		else{
			echo "<script>alert('Login Gagal! Silahkan cek kembali username & password Anda'); window.location='index.php'</script>";

		}
	}	

?>

 