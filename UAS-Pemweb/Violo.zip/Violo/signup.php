<?php
session_start();
if (isset($_SESSION['username'])) {
  header("location:dash.php");
}

include 'koneksi.php';

if (isset($_POST['daftar'])) {

  $email = $_POST['email'];
  $username = $_POST['username'];
  $password = md5($_POST['password']);
  $no_tlp = $_POST['no_tlp'];
  $role = $_POST['role'];
  // $ava = $_FILES['ava']['name'];
  // $ekstensi = $_FILES['ava']['tmp_name'];
		
  //   $lokasi = "img/" . $ava;

  //   move_uploaded_file($ekstensi, $lokasi);

  $sql = mysqli_query($conn, "INSERT INTO `user`(email, username, password, no_telp, role) VALUES('$email', '$username', '$password', '$no_tlp', '$role')");

?>

  <script type="text/javascript">
    alert("Sign Up berhasil! Silakan melakukan sign in");
    window.location.href = "index.php"
  </script>

<?php  }
?>