<?php 
	include 'koneksi.php';
	include 'link.php';

	if (isset($_POST['simpan'])) {
		$email = $_POST['email'];
		$username = $_POST['username'];
		$password = md5($_POST['password']);
        $no_telp = $_POST['no_telp'];
		$role = $_POST['role'];

		$query = mysqli_query($conn, "INSERT INTO user (email, username, password, no_telp, role) VALUES ('$email', '$username', '$password', '$no_telp', '$role')");

		if ($query) {
            echo "<script>alert('Data Users berhasil ditambahkan'); window.location='pengguna.php';</script>";
		}else{
			echo "<script>alert('Data Users gagal ditambahkan'); window.location='tambah_user.php';</script>";
		}
	}
 ?><br>

 	<div class="container">
 		<div class="panel panel-default">
		<div class="panel-heading">
			<h2>Tambah Users</h2>
			<a href="pengguna.php" class="btn mb-5" style="color:#EF9273;">Kembali</a>
		</div>

	<div class="panel-body">
 		<form action="" method="POST">
 	
	 <div class="form-group">
			<label class="control-label col-sm-2" name="email">E-mail</label>
		 <div class="col-md-10" >
			<input type="text" name="email" class="form-control" required>
	    </div>
	</div>

	<div class="form-group mt-4">
			<label class="control-label col-sm-2" name="username">Nama Pengguna</label>
		 <div class="col-md-10" >
			<input type="text" name="username" class="form-control" required>
	    </div>
	</div>

 	<div class="form-group mt-4">
			<label class="control-label col-sm-2" name="password">Kata Sandi</label>
		 <div class="col-md-10" >
			<input type="password" name="password" class="form-control" required>
	    </div>
	</div>

    <div class="form-group mt-4">
			<label class="control-label col-sm-2" name="no_telp">No. Telpon</label>
		 <div class="col-md-10" >
			<input type="text" name="no_telp" class="form-control" required>
	    </div>
	</div>

	<div class="list-group mt-4">
		<label class="control-label col-sm-2" name="role">Jabatan</label>
		 <div class="col-md-10" >
			<select name="role" class="form-control" required>
				<option selected disabled>Pilih Jabatan</option>
				<option value="Admin">Admin</option>
				<option value="Seller">Seller</option>
                <option value="Buyer">Buyer</option>
			</select>	
		</div>
	</div>

	<div class="form-group mt-4">        
  		<div class="col-sm-offset-2 col-sm-10">
      		<!-- <button type="submit" class="btn" name="simpan">Simpan</button> -->
			<button type="submit" style="width: 150px; background: #EF9273; border-style: 1 solid;" class="btn text-light mt-3" name="simpan">Submit</button>        </div>
    </div>

 </form>

</div>
</div>
</div>

 <?php 
 	include 'footer.php';

?>


  