-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 16, 2021 at 07:20 PM
-- Server version: 5.7.24
-- PHP Version: 7.2.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `violo`
--

-- --------------------------------------------------------

--
-- Table structure for table `buyer`
--

CREATE TABLE `buyer` (
  `id_buyer` int(11) NOT NULL,
  `nama_buyer` varchar(50) NOT NULL,
  `bio_buyer` text NOT NULL,
  `wa` varchar(30) NOT NULL,
  `foto` varchar(1500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buyer`
--

INSERT INTO `buyer` (`id_buyer`, `nama_buyer`, `bio_buyer`, `wa`, `foto`) VALUES
(10, 'triana', 'asasasasa', '058163548941', ''),
(11, 'nana', 'dsfdsf', '05113151321', 'twt.png'),
(12, 'nana', 'asdasdasdsadasdsssss', '05113151321', 'category.png'),
(13, 'posdsdsds', 'fgfdgsdfg', '84084848', 'pass.png');

-- --------------------------------------------------------

--
-- Table structure for table `explore`
--

CREATE TABLE `explore` (
  `id_ex` int(11) NOT NULL,
  `foto` varchar(150) NOT NULL,
  `shop_gallery` varchar(150) NOT NULL,
  `nama_seller` varchar(100) NOT NULL,
  `kategori` varchar(20) NOT NULL,
  `nama_shop` varchar(1500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `explore`
--

INSERT INTO `explore` (`id_ex`, `foto`, `shop_gallery`, `nama_seller`, `kategori`, `nama_shop`) VALUES
(1, 'user.png', '4.jpeg', 'Triana Micku Kuswara', 'Copywriting', 'nanninu'),
(2, 'user.png', '4.jpeg', 'Bagoes Wicaksono', 'Logo Design', 'bagoeswicak'),
(3, 'user.png', '4.jpeg', 'Triana Micku Kuswara', 'Web Design', 'nannanananaa'),
(4, 'user.png', '4.jpeg', 'Bagoes Wicaksono', 'Video Editor', 'bagoessssssssssss');

-- --------------------------------------------------------

--
-- Table structure for table `gambar`
--

CREATE TABLE `gambar` (
  `id_gambar` int(11) NOT NULL,
  `gmb_index` varchar(150) NOT NULL,
  `gmb_profile` varchar(150) NOT NULL,
  `gmb_galeri` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` int(11) NOT NULL,
  `kategori` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `kategori`) VALUES
(1, 'Copywriting'),
(2, 'Web Design'),
(3, 'Logo Design'),
(4, 'Video Editor');

-- --------------------------------------------------------

--
-- Table structure for table `seller`
--

CREATE TABLE `seller` (
  `id_seller` int(11) NOT NULL,
  `nama_shop` varchar(150) NOT NULL,
  `nama_seller` varchar(50) NOT NULL,
  `kategori` varchar(20) NOT NULL,
  `bio_seller` text NOT NULL,
  `ig` varchar(100) NOT NULL,
  `fb` varchar(100) NOT NULL,
  `Li` varchar(100) NOT NULL,
  `wa` varchar(100) NOT NULL,
  `logo` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seller`
--

INSERT INTO `seller` (`id_seller`, `nama_shop`, `nama_seller`, `kategori`, `bio_seller`, `ig`, `fb`, `Li`, `wa`, `logo`) VALUES
(2, 'maulidts', 'Maulidta Naflah', 'Video Editor', 'You need something?', 'https://instagram.com/violo_ig', 'https://instagram.com/violo_ig', 'https://instagram.com/violo_ig', '08458418515', 'Hero2.png'),
(3, 'Bagoes Art', 'Muhammad Bagoes W.', 'Logo Design', '-', 'https://instagram.com/violo_ig', '-https://instagram.com/violo_ig', 'https://instagram.com/violo_ig', '081384874645', '4.jpeg'),
(4, 'Bagoes Design', 'Muhammad Bagoes W.', 'Web Design', '-', 'https://instagram.com/violo_ig', '-https://instagram.com/violo_ig', 'https://instagram.com/violo_ig', '081384874645', 'Hero2.png');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `no_telp` varchar(15) NOT NULL,
  `role` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `email`, `username`, `password`, `no_telp`, `role`) VALUES
(1, 'trianana@gmail.com', 'Triana Micku', 'e10adc3949ba59abbe56e057f20f883e', '081246843256', 'Admin'),
(2, 'bagoess@gmail.com', 'Bagoes Wicak', 'e10adc3949ba59abbe56e057f20f883e', '08121654846', 'Buyer'),
(3, 'maulidta@gmail.com', 'Maulidta', 'e10adc3949ba59abbe56e057f20f883e', '083816548489', 'Seller');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buyer`
--
ALTER TABLE `buyer`
  ADD PRIMARY KEY (`id_buyer`);

--
-- Indexes for table `explore`
--
ALTER TABLE `explore`
  ADD PRIMARY KEY (`id_ex`);

--
-- Indexes for table `gambar`
--
ALTER TABLE `gambar`
  ADD PRIMARY KEY (`id_gambar`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `seller`
--
ALTER TABLE `seller`
  ADD PRIMARY KEY (`id_seller`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `buyer`
--
ALTER TABLE `buyer`
  MODIFY `id_buyer` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `explore`
--
ALTER TABLE `explore`
  MODIFY `id_ex` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `gambar`
--
ALTER TABLE `gambar`
  MODIFY `id_gambar` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `seller`
--
ALTER TABLE `seller`
  MODIFY `id_seller` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
